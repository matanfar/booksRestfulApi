package com.example.clientserverrestfulapi;

import android.net.Uri;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;

public class ConnectivityHelper {
    /*
    GET https://www.googleapis.com/books/v1/volumes?q={search terms}
    OR
    GET https://www.googleapis.com/books/v1/volumes/volumeId

    For example
   GET https://books.googleapis.com/books/v1/volumes?q=alice&maxResults=2&orderBy=newest


    When working with Web API's, it is good practice to save the base URL.
    Then build upon it.
    Declare constants
     */

    private static final String BASE_URL = "https://www.googleapis.com/books/v1/volumes?";
    private static final String QUERY = "q";
    private static final String NUM_RESULT = "maxResults";
    private static final String ORDER = "orderBy";

    // for example:


    static String getInfo(String query){
        HttpURLConnection connection = null;
        BufferedReader bufferedReader = null;
        String bookAsString = null;

        try{
            // Uri.builder - invoked when using buildUpon method
            Uri uri = Uri.parse(BASE_URL)
                    .buildUpon()
                    .appendQueryParameter(QUERY,query)
                    .appendQueryParameter(NUM_RESULT,"2")
                    .appendQueryParameter(ORDER,"newest")
                    .build();


            // open an HTTP connection to Web server. This may cause a problem

        } catch (IOException ioe){
            ioe.printStackTrace();
        } finally{
            // close all IO resource demanding objects (streams)
        }


        return bookAsString;
    }
}
