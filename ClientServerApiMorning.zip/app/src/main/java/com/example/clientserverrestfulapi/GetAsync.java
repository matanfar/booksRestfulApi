package com.example.clientserverrestfulapi;

import android.os.AsyncTask;
import android.widget.TextView;

import java.lang.ref.WeakReference;

public class GetAsync extends AsyncTask<String,Void,String> {
    // Leaky context - Possible memory leak due to memory addresses that are no longer
    // accessible but can NOT be garbage-collected
//    private TextView titleInfoFromMain;
//    private TextView authorInfoFromMain;

    private WeakReference<TextView> safeTitleInfoFromMain;
    private WeakReference<TextView> safeAuthorInfoFromMain;



    // Leaky context - Possible memory leak due to memory addresses that are no longer
    public GetAsync(TextView titleInfo, TextView authorInfo){
//        this.titleInfoFromMain = titleInfo;
//        this.authorInfoFromMain = authorInfo;
        this.safeTitleInfoFromMain = new WeakReference<>(titleInfo);
        this.safeAuthorInfoFromMain = new WeakReference<>(authorInfo);
    }

    /**
     *
     * @param strings - String... is an array of Strings of unknown size
     * @return
     */
    @Override
    protected String doInBackground(String... strings) {
        /*
        Create a URI including query string
        Create HTTP connection using the url
        Create an InputStream from the response from the server
        Read the response as an Array of JSON Objects
        Parse each JSON object
        DO more stuff
         */
    }

    @Override
    protected void onPostExecute(String s){
//        titleInfoFromMain.setText();
//        authorInfoFromMain.setText();
        safeTitleInfoFromMain.get().setText("");
        safeAuthorInfoFromMain.get().setText("");
    }

}
